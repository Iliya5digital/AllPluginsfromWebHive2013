<?php

return array(
    array(
        'title' => "Social Sharing",
        'description' => 'Displays Facebook, twitter, g+ buttons.',
        'category' => 'WebHive Core',
        'type' => 'widget',
        'name' => 'whcore.share-social',
        'defaultParams' => array(
            'title' => "Social Sharing"
        )
    ),
);
?>
