<?php

class Schedule_IndexController extends Core_Controller_Action_Standard {

    public function init() {
        // only show to member_level if authorized
        if (!$this->_helper->requireAuth()->setAuthParams('schedule', null, 'view')->isValid())
            return;
    }

    public function listAction() {
        $this->_helper->layout->setLayout('default-simple');
        // Preload info
        $this->view->viewer = $viewer = Engine_Api::_()->user()->getViewer();

        $timezone = $this->view->locale()->getTimezone();

        $owner = Engine_Api::_()->getItem('user', (int) $this->_getParam('user_id'));

        if (!Engine_Api::_()->core()->hasSubject())
            Engine_Api::_()->core()->setSubject($owner);


        if (!$this->_helper->requireSubject()->isValid())
            return;
        $this->view->paging = ($this->_getParam('paging', false));
        $date = $this->_getParam('date', '');

        if (false === checkdate(mb_substr($date, 5, 2), mb_substr($date, 8), mb_substr($date, 0, 4)))
            return;

        $year = mb_substr($date, 0, 4);
        $month = mb_substr($date, 5, 2);
        $day = mb_substr($date, 8);

        $viewDate = array('year' => $year, 'month' => $month, 'day' => $day);

        $prev = date("Y-m-d", mktime(0, 0, 0, $month, $day - 1, $year));
        $next = date("Y-m-d", mktime(0, 0, 0, $month, $day + 1, $year));

        $setting = Engine_Api::_()->getApi('settings', 'schedule')->getFlatSetting($owner->getIdentity(), Engine_Api::_()->getApi('settings', 'core')->getFlatSetting('schedule'));
        $step = (int) substr($setting['time_start'], 0, 2) * 6;

        $oldTz = date_default_timezone_get();
        date_default_timezone_set($timezone);
        $start_time = strtotime($date . ' ' . $setting['time_start']);
        $end_time = strtotime($date . ' ' . $setting['time_end']);
        date_default_timezone_set($oldTz);

        $user_start_time = date('Y-m-d H:i:s', $start_time);
        $user_end_time = date('Y-m-d H:i:s', $end_time);

        $schedule = Engine_Api::_()->getItemTable('schedule')->getDaySchedule(array(
            'date' => $date,
            'owner_id' => $owner->getIdentity(),
            'owner_type' => 'user'
        ));

        list($totalStartTimeH, $totalStartTimeM) = explode(':', $setting['time_start']);
        list($totalEndTimeH, $totalEndTimeM) = explode(':', $setting['time_end']);

        $hours = array();
        for ($i = (int) $totalStartTimeH; $i <= (int) $totalEndTimeH - 1; $i++) {
            $hours[$i] = $i;
        }

        foreach ($schedule->toArray() as $item) {
            if ($item['owner_id'] != $viewer->getIdentity()) {
                $notificationsTable = Engine_Api::_()->getDbTable('notifications', 'activity');
                $select = $notificationsTable->select();
                $select->where('object_type = ?', 'schedule')
                        ->where('object_id = ?', $item['schedule_id'])
                        ->where('user_id =?', $viewer->getIdentity())
                        ->where('mitigated = ?', 0);
                $invite = $notificationsTable->fetchRow($select);

                $item['has_invite'] = false;
                if ($invite != null && count($invite) == 1) {
                    $item['has_invite'] = true;
                    $item['invite'] = $invite;
                }
            }

            $event = Engine_Api::_()->getItem('schedule', $item['schedule_id']);

            $item['private'] = true;
            if (Engine_Api::_()->authorization()->isAllowed($event, $viewer, 'view')) {
                $item['private'] = false;
            }

            // Convert times
            $item['start_time'] = $this->view->locale()->toTime($item['start_time'], array('format' => 'H:mm'));
            $item['end_time'] = $this->view->locale()->toTime($item['end_time'], array('format' => 'H:mm'));


            $rowspan = explode(':', $item['end_time']);
            $key = explode(':', $item['start_time']);


            //counting params
            $item['start'] = self::_toMin($item['start_time']) - $step;
            $item['end'] = (self::_toMin($item['end_time']) - $step) - ($this->_toMin($item['start_time']) - $step);

            for ($i = $rowspan[0] - 1; $i >= $key[0]; $i--) {
                unset($hours[$i]);
            }

            if ($rowspan[1] != 00) {
                unset($hours[$rowspan[0]]);
            }

            $item['short'] = false;

            $end_time = self::_toMin($item['end_time']);
            $start_time = self::_toMin($item['start_time']);

            if (($end_time - $start_time) <= 2) {
                $item['short'] = true;
            }
            if (strtotime($item['start_time']) >= strtotime($setting['time_start']) && strtotime($item['end_time']) <= strtotime($setting['time_end']))
                $tmp[] = $item;
            else
                $notInRange[] = $item;
        }

        $isSelf = true;
        if (!$viewer->isSelf($owner)) {
            $isSelf = false;
        }

        $this->view->data = array(
            'viewer' => $viewer,
            'owner' => $owner,
            'date' => $viewDate,
            'prev' => $prev,
            'next' => $next,
            'setting' => $setting,
            'hours' => $hours,
            'isSelf' => $isSelf,
            'schedule' => isset($tmp) ? $tmp : null,
            'notinrange' => isset($notInRange) ? $notInRange : null,
            'step' => $step
        );
    }

    public function createAction() {
        if (!$this->_helper->requireUser()->isValid())
            return;
        if (!$this->_helper->requireAuth()->setAuthParams('schedule', null, 'create')->isValid())
            return;

        //prepare data
        $viewer = Engine_Api::_()->user()->getViewer();
        Engine_Api::_()->core()->setSubject($viewer);

        $parent_id = $viewer->getIdentity();

        //getting correct date wich depends on timezone
        $oldTz = date_default_timezone_get();
        date_default_timezone_set($viewer->timezone);
        $this->view->cur_day = date('d-m-Y H:i', strtotime('now'));
        date_default_timezone_set($oldTz);

        $data = $this->_getParam('data', '');
        $date = explode(' ', $data);

        // Create form
        $this->view->form = $form = new Schedule_Form_Create(array(
            'parent_id' => $parent_id,
        ));
        $from_popup = false;
        if ($date[0] != '') {
            $from_popup = true;
            $form->populate(array(
                'date' => $date[0],
                'start_time' => $date[1] . ':00',
                'end_time' => $date[1] + 1 . ':00'
            ));
        } else {
            $form->populate(array(
                'start_time' => '8:00',
                'end_time' => '9:00'
            ));
            $form->cancel->setAttrib('onclick', 'parent.Smoothbox.close();');
        }

        // If not post or form not valid, return
        if (!$this->getRequest()->isPost()) {
            return;
        }

        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }

        // Process
        $values = $form->getValues();

        $values['owner_id'] = $viewer->getIdentity();
        $values['start_time'] = $values['date'] . ' ' . $values['start_time'];
        $values['end_time'] = $values['date'] . ' ' . $values['end_time'];

        if (!in_array($values['reminder'], array('-1', '0', '30', '60', '90', '120', '150', '180', '1440')))
            $values['reminder'] = '-1';

        // Convert times
        $oldTz = date_default_timezone_get();
        date_default_timezone_set($viewer->timezone);
        $start_time = strtotime($values['start_time']);
        $end_time = strtotime($values['end_time']);
        date_default_timezone_set($oldTz);
        $values['start_time'] = date('Y-m-d H:i:s', $start_time);
        $values['end_time'] = date('Y-m-d H:i:s', $end_time);

        $db = Engine_Api::_()->getDbtable('schedules', 'schedule')->getAdapter();
        $db->beginTransaction();

        try {
            // Create event
            $table = Engine_Api::_()->getDbtable('schedules', 'schedule');

            $event = $table->createRow();

            $event->setFromArray($values);
            $event->save();
            $url = $event->getHref();

            // Auth
            $auth = Engine_Api::_()->authorization()->context;
            $roles = array('owner', 'owner_member', 'owner_member_member', 'owner_network', 'everyone');

            if (empty($values['auth_view'])) {
                $values['auth_view'] = 'everyone';
            }

            $viewMax = array_search($values['auth_view'], $roles);

            foreach ($roles as $i => $role) {
                $auth->setAllowed($event, $role, 'view', ($i <= $viewMax));
            }

            // Add action
            $activityApi = Engine_Api::_()->getDbtable('actions', 'activity');

            $action = $activityApi->addActivity($viewer, $event, 'schedule_create');

            if ($action) {
                $activityApi->attachActivity($action, $event);
            }

            if ($values['reminder'] != '-1') {
                $reminderTable = Engine_Api::_()->getDbTable('reminders', 'schedule');
                $reminder = $reminderTable->createRow();
                $reminder->user_id = $viewer->getIdentity();

                $reminder_date = strtotime($values['start_time']) - ($values['reminder'] * 60);
                $reminder->date = date('Y-m-d H:i:s', $reminder_date);
                $reminder->schedule_id = $event->getIdentity();
                $reminder->time = $values['reminder'];
                $reminder->save();
            }

            if ($values['recurring'] == 1) {
                if ($values['repeat'] <= 10) {
                    switch ($values['every']) {
                        case 'day':
                            for ($c = 1; $c <= $values['repeat']; $c++) {
                                $date_tmp = new DateTime($values['start_time']);
                                $values['start_time'] = $date_tmp->modify('+1 day')->format('Y-m-d H:i:s');
                                $values['date'] = $date_tmp->format('Y-m-d');

                                $date_tmp = new DateTime($values['end_time']);
                                $values['end_time'] = $date_tmp->modify('+1 day')->format('Y-m-d H:i:s');

                                $event = $table->createRow();

                                $event->setFromArray($values);
                                $event->save();

                                // Auth
                                $auth = Engine_Api::_()->authorization()->context;
                                $roles = array('owner', 'owner_member', 'owner_member_member', 'owner_network', 'registered', 'everyone');

                                if (empty($values['auth_view'])) {
                                    $values['auth_view'] = 'everyone';
                                }

                                $viewMax = array_search($values['auth_view'], $roles);

                                foreach ($roles as $i => $role) {
                                    $auth->setAllowed($event, $role, 'view', ($i <= $viewMax));
                                }

                                // Add action
                                $activityApi = Engine_Api::_()->getDbtable('actions', 'activity');

                                $action = $activityApi->addActivity($viewer, $event, 'schedule_create');

                                if ($action) {
                                    $activityApi->attachActivity($action, $event);
                                }

                                if ($values['reminder'] != '-1') {
                                    $reminderTable = Engine_Api::_()->getDbTable('reminders', 'schedule');
                                    $reminder = $reminderTable->createRow();
                                    $reminder->user_id = $viewer->getIdentity();

                                    $reminder_date = strtotime($values['start_time']) - $values['reminder'];
                                    $reminder->date = date('Y-m-d H:i:s', $reminder_date);
                                    $reminder->schedule_id = $event->getIdentity();
                                    $reminder->save();
                                }

                                // Commit
                                //$db->commit();
                            }
                            break;
                        case 'week':
                            for ($c = 1; $c <= $values['repeat']; $c++) {
                                $date_tmp = new DateTime($values['start_time']);
                                $values['start_time'] = $date_tmp->modify('+1 week')->format('Y-m-d H:i:s');
                                $values['date'] = $date_tmp->format('Y-m-d');

                                $date_tmp = new DateTime($values['end_time']);
                                $values['end_time'] = $date_tmp->modify('+1 week')->format('Y-m-d H:i:s');

                                $event = $table->createRow();

                                $event->setFromArray($values);
                                $event->save();

                                // Auth
                                $auth = Engine_Api::_()->authorization()->context;
                                $roles = array('owner', 'owner_member', 'owner_member_member', 'owner_network', 'registered', 'everyone');

                                if (empty($values['auth_view'])) {
                                    $values['auth_view'] = 'everyone';
                                }

                                $viewMax = array_search($values['auth_view'], $roles);

                                foreach ($roles as $i => $role) {
                                    $auth->setAllowed($event, $role, 'view', ($i <= $viewMax));
                                }

                                // Add action
                                $activityApi = Engine_Api::_()->getDbtable('actions', 'activity');

                                $action = $activityApi->addActivity($viewer, $event, 'schedule_create');

                                if ($action) {
                                    $activityApi->attachActivity($action, $event);
                                }

                                if ($values['reminder'] != '-1') {
                                    $reminderTable = Engine_Api::_()->getDbTable('reminders', 'schedule');
                                    $reminder = $reminderTable->createRow();
                                    $reminder->user_id = $viewer->getIdentity();

                                    $reminder_date = strtotime($values['start_time']) - $values['reminder'];
                                    $reminder->date = date('Y-m-d H:i:s', $reminder_date);
                                    $reminder->schedule_id = $event->getIdentity();
                                    $reminder->save();
                                }

                                // Commit
                                //$db->commit();
                            }
                            break;
                        case 'month':
                            for ($c = 1; $c <= $values['repeat']; $c++) {
                                $date_tmp = new DateTime($values['start_time']);
                                $values['start_time'] = $date_tmp->modify('+1 month')->format('Y-m-d H:i:s');
                                $values['date'] = $date_tmp->format('Y-m-d');

                                $date_tmp = new DateTime($values['end_time']);
                                $values['end_time'] = $date_tmp->modify('+1 month')->format('Y-m-d H:i:s');

                                $event = $table->createRow();

                                $event->setFromArray($values);
                                $event->save();

                                // Auth
                                $auth = Engine_Api::_()->authorization()->context;
                                $roles = array('owner', 'owner_member', 'owner_member_member', 'owner_network', 'registered', 'everyone');

                                if (empty($values['auth_view'])) {
                                    $values['auth_view'] = 'everyone';
                                }

                                $viewMax = array_search($values['auth_view'], $roles);

                                foreach ($roles as $i => $role) {
                                    $auth->setAllowed($event, $role, 'view', ($i <= $viewMax));
                                }

                                // Add action
                                $activityApi = Engine_Api::_()->getDbtable('actions', 'activity');

                                $action = $activityApi->addActivity($viewer, $event, 'schedule_create');

                                if ($action) {
                                    $activityApi->attachActivity($action, $event);
                                }

                                if ($values['reminder'] != '-1') {
                                    $reminderTable = Engine_Api::_()->getDbTable('reminders', 'schedule');
                                    $reminder = $reminderTable->createRow();
                                    $reminder->user_id = $viewer->getIdentity();

                                    $reminder_date = strtotime($values['start_time']) - $values['reminder'];
                                    $reminder->date = date('Y-m-d H:i:s', $reminder_date);
                                    $reminder->schedule_id = $event->getIdentity();
                                    $reminder->save();
                                }

                                // Commit
                                //$db->commit();
                            }
                            break;
                        case 'year':
                            for ($c = 1; $c <= $values['repeat']; $c++) {
                                $date_tmp = new DateTime($values['start_time']);
                                $values['start_time'] = $date_tmp->modify('+1 year');
                                $values['start_time'] = $values['start_time']->format('Y-m-d H:i:s');
                                $values['date'] = $date_tmp->format('Y-m-d');

                                $date_tmp = new DateTime($values['end_time']);
                                $values['end_time'] = $date_tmp->modify('+1 year');
                                $values['end_time'] = $values['end_time']->format('Y-m-d H:i:s');

                                $event = $table->createRow();

                                $event->setFromArray($values);
                                $event->save();

                                // Auth
                                $auth = Engine_Api::_()->authorization()->context;
                                $roles = array('owner', 'owner_member', 'owner_member_member', 'owner_network', 'registered', 'everyone');

                                if (empty($values['auth_view'])) {
                                    $values['auth_view'] = 'everyone';
                                }

                                $viewMax = array_search($values['auth_view'], $roles);

                                foreach ($roles as $i => $role) {
                                    $auth->setAllowed($event, $role, 'view', ($i <= $viewMax));
                                }

                                // Add action
                                $activityApi = Engine_Api::_()->getDbtable('actions', 'activity');

                                $action = $activityApi->addActivity($viewer, $event, 'schedule_create');

                                if ($action) {
                                    $activityApi->attachActivity($action, $event);
                                }

                                if ($values['reminder'] != '-1') {
                                    $reminderTable = Engine_Api::_()->getDbTable('reminders', 'schedule');
                                    $reminder = $reminderTable->createRow();
                                    $reminder->user_id = $viewer->getIdentity();

                                    $reminder_date = strtotime($values['start_time']) - $values['reminder'];
                                    $reminder->date = date('Y-m-d H:i:s', $reminder_date);
                                    $reminder->schedule_id = $event->getIdentity();
                                    $reminder->save();
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            // Commit
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }


        return $this->_forward('success', 'utility', 'core', array(
                    'parentRedirect' => $url,
                    'messages' => array(Zend_Registry::get('Zend_Translate')->_('Event has been successfully added.')),
        ));
    }

    public function settingsAction() {
        if (!$this->_helper->requireUser()->isValid())
            return;
        if (!$this->_helper->requireAuth()->setAuthParams('schedule', null, 'create')->isValid())
            return;

        //prepare data
        $viewer = Engine_Api::_()->user()->getViewer();
        Engine_Api::_()->core()->setSubject($viewer);

        $user_id = $viewer->getIdentity();

        $this->view->form = $form = new Schedule_Form_Settings(array(
            'parent_id' => $user_id,
        ));

        $setting = Engine_Api::_()->getApi('settings', 'schedule')->getFlatSetting($viewer->getIdentity(), Engine_Api::_()->getApi('settings', 'core')->getFlatSetting('schedule'));


        $form->populate($setting);

        // If not post or form not valid, return
        if (!$this->getRequest()->isPost()) {
            return;
        }

        if (!$form->isValid($this->getRequest()->getPost())) {
            return;
        }

        $values = $form->getValues();
        //$values['user_id'] = $viewer->getIdentity();

        Engine_Api::_()->getApi('settings', 'schedule')->setFlatSetting((string) $viewer->getIdentity(), $values);


        $this->view->status = true;
        $this->view->message = Zend_Registry::get('Zend_Translate')->_('Your options have been saved.');
        return $this->_forward('success', 'utility', 'core', array(
                    'parentRedirect' => $viewer->getHref() . '/tab/schedule.profile-schedule',
                    'messages' => Array($this->view->message),
                    'tab' => 'schedule.profile-schedule'
        ));
    }

    protected function _toMin($val) {
        if (is_string($val)) {
            $val = explode(':', $val);
            return ((int) $val[0] * 6 + (int) $val[1] / 10);
        }

        if (isArray($val)) {
            return ((int) $val[0] * 6 + (int) $val[1] / 10);
        }
    }

}
