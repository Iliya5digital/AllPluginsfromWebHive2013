<?php

class Schedule_Widget_ProfileScheduleController extends Engine_Content_Widget_Abstract {

    public function indexAction() {
        //Don't render this if not authorized
        $viewer = Engine_Api::_()->user()->getViewer();
        if (!Engine_Api::_()->core()->hasSubject()) {
            return $this->setNoRender();
        }

        $timezone = Zend_Registry::get('Zend_View')->locale()->getTimezone();

        // Get subject and check auth
        $subject = Engine_Api::_()->core()->getSubject('user');
        if (!$subject->authorization()->isAllowed($viewer, 'view')) {
            return $this->setNoRender();
        }

        // Just remove the title decorator
        $this->getElement()->removeDecorator('Title');

        $date = $this->_getParam('date', '');
        $this->view->open = $open = Zend_Controller_Front::getInstance()->getRequest()->getParam('open', '');

        if ($open != '') {
            //kicking out if date format is invalid
            if (!checkdate(substr($open, 5, 2), 1, substr($open, 0, 4)))
                return $this->setNoRender();
            $date = $open;
        }

        if ($date != '') {
            //kicking out if date format is invalid
            if (!checkdate(substr($date, 5, 2), 1, substr($date, 0, 4)))
                return $this->setNoRender();
        }
        else {
            //getting correct date wich depends on timezone
            $oldTz = date_default_timezone_get();
            date_default_timezone_set($timezone);
            $date = date('Y-m');
            date_default_timezone_set($oldTz);
        }

        $year = substr($date, 0, 4);
        $month = substr($date, 5, 2);

        $prev = date("Y-m", mktime(0, 0, 0, $month - 1, 1, $year));
        $next = date("Y-m", mktime(0, 0, 0, $month + 1, 1, $year));

        $num_days = cal_days_in_month(CAL_GREGORIAN, $month, $year); // counting days in month

        $skip = date("w", mktime(0, 0, 0, $month, 1, $year)); // first day of month
        if ($skip < 0) {
            $skip = 6;
        }

        if ($skip > 0) {
            if ($month != '01')
                $num_days_prev = cal_days_in_month(CAL_GREGORIAN, $month - 1, $year) - $skip + 1; // counting days in month
            else
                $num_days_prev = cal_days_in_month(CAL_GREGORIAN, 12, $year - 1) - $skip + 1; // counting days in month
        }

        //correct surrent day, depends on timezone
        $oldTz = date_default_timezone_get();
        date_default_timezone_set($timezone);
        $cur_day = date('j', strtotime('now'));
        date_default_timezone_set($oldTz);

        //flag to add a links "Add Event" && "Settings"
        $isSelf = true;
        if (!$viewer->isSelf($subject)) {
            $isSelf = false;
        }

        $table = Engine_Api::_()->getDbTable('schedules', 'schedule');
        $select = $table->select();
        $select->distinct()
                ->from($table, array('DAY(date) as day', 'start_time', 'end_time'))
                ->where('YEAR(date) = ?', $year)
                ->where('MONTH(date) = ?', $month)
                ->where('owner_id = ?', Engine_Api::_()->core()->getSubject()->getIdentity())
                ->where('owner_type = ?', 'user');
        $schedule = $table->fetchAll($select);

        $setting = Engine_Api::_()->getApi('settings', 'schedule')->getFlatSetting($subject->getIdentity(), Engine_Api::_()->getApi('settings', 'core')->getFlatSetting('schedule'));

        list($totalStartTimeH, $totalStartTimeM) = explode(':', $setting['time_start']);
        list($totalEndTimeH, $totalEndTimeM) = explode(':', $setting['time_end']);

        $totalScheduleTime = (((int) $totalEndTimeH * 6) + ((int) $totalEndTimeM / 10)) - (((int) $totalStartTimeH * 6) + ((int) $totalStartTimeM / 10));

        if ($schedule) {
            $events_count = $schedule->count();
            foreach ($schedule as $day) {
                $day->start_time = $this->view->locale()->toTime($day->start_time, array('format' => 'H:mm'));
                $day->end_time = $this->view->locale()->toTime($day->end_time, array('format' => 'H:mm'));

                list($sTime_h, $sTimeM) = explode(':', $day->start_time);
                list($eTime_h, $eTimeM) = explode(':', $day->end_time);

                $sMins = ($sTime_h * 6) + ($sTimeM / 10);
                $eMins = ($eTime_h * 6) + ($eTimeM / 10);

                if (isset($total[$day->day]['busy'])) {
                    $total[$day->day]['busy'] += ($eMins - $sMins);
                } else {
                    $total[$day->day]['busy'] = ($eMins - $sMins);
                }

                if (isset($total[$day->day]['total_count'])) {
                    $total[$day->day]['total_count']++;
                } else {
                    $total[$day->day]['total_count'] = 1;
                }

                if ($total[$day->day]['busy'] >= $totalScheduleTime) {
                    $tmp[$day->day]['busy'] = 'full';
                } else {
                    $tmp[$day->day]['busy'] = 'partial';
                }
                $tmp[$day->day]['total_count'] = $total[$day->day]['total_count'];
            }
        }

        $this->view->data = array(
            'year' => $year,
            'month' => $month,
            'prev' => $prev,
            'next' => $next,
            'num_days' => $num_days,
            'skip' => $skip,
            'num_days_prev' => isset($num_days_prev) ? $num_days_prev : null,
            'cur_day' => $cur_day,
            'isSelf' => $isSelf,
            'busydays' => isset($tmp) ? $tmp : null,
            'events_count' => $events_count
        );
    }

}