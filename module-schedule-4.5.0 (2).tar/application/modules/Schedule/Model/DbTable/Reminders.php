<?php

class Schedule_Model_DbTable_Reminders extends Engine_Db_Table {

    protected $_rowClass = "Schedule_Model_Reminder";

}