<?php

class Schedule_Model_DbTable_Schedules extends Engine_Db_Table {

    protected $_rowClass = "Schedule_Model_Schedule";

    public function getDaySchedule($params = array()) {
        $select = $this->select();
        if (isset($params['date']))
            $select->where('date = ?', $params['date']);
        if (isset($params['owner_id']))
            $select->where('owner_id = ?', $params['owner_id']);
        if (isset($params['start_time']))
            $select->where('start_time >= ?', $params['start_time']);
        if (isset($params['end_time']))
            $select->where('end_time <= ?', $params['end_time']);
        if (isset($params['owner_type']))
            $select->where('owner_type = ?', $params['owner_type']);
        
        $select->order('start_time ASC');
        
        return $this->fetchAll($select);
    }

}