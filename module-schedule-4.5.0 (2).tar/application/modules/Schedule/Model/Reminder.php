<?php

class Schedule_Model_Reminder extends Core_Model_Item_Abstract {

    protected $_parent_is_owner = true;

}