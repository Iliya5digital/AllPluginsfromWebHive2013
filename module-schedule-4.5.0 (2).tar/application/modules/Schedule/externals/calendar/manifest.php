<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'calendar',
    'version' => '4.0.1',
    'revision' => '$Revision: 7593 $',
    'path' => 'externals/calendar',
    'repository' => 'socialengine.net',
    'title' => 'Calendar',
    'author' => 'Webligo Developments',
    'changeLog' => array(
      '4.0.1' => array(
        'manifest.php' => 'Incremented version',
        'styles.css' => 'Improved localization and RTL support',
      ),
    ),
    'directories' => array(
      'externals/calendar',
    )
  )
) ?>