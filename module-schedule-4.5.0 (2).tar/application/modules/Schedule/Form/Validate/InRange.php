<?php

class Schedule_Form_Validate_InRange extends Zend_Validate_Abstract {
    const IS_IN_RANGE = 'isInRange';
    const DUPLICATE_TIME = 'duplicateEvent';

    protected $_messageTemplates = array(
        self::IS_IN_RANGE => 'You can\'t be in a few places in one time',
        self::DUPLICATE_TIME => 'Duplicate time',
    );
    protected $_key;
    protected $_params;

    public function __construct($params) {
        $this->_params = $params;
    }

    protected function _query($tmp = null) {
        //getting default adapter
        $this->_adapter = Zend_Db_Table_Abstract::getDefaultAdapter();
        if (null === $this->_adapter) {
            throw new Zend_Validate_Exception('No database adapter present');
        }
        $id = Engine_Api::_()->core()->getSubject()->getIdentity();

        /**
         * Build query
         */
        //edit
        if ($this->_params['action'] == 'edit') {
            $select = new Zend_Db_Select($this->_adapter);
            $select->from('engine4_schedule_schedules', array('*'))
                    ->where('owner_id = ?', $tmp['user'])
                    ->where('schedule_id = ?', $id);
            $res = $this->_adapter->fetchRow($select, array(), Zend_Db::FETCH_ASSOC);

            //if user modify enythinf exept date and times
            if ($res['date'] == $tmp['date'] && $res['start_time'] == $tmp['start_time'] && $res['end_time'] == $tmp['end_time']) {
                return true;
            }
        }

        $select = new Zend_Db_Select($this->_adapter);
        $select->from('engine4_schedule_schedules', array('schedule_id', 'start_time', 'end_time'));

        $select->where('date = ?', date('Y-m-d', strtotime($tmp['date']['date'])))
                ->where('owner_id = ?', $tmp['user']);

        if ($this->_params['action'] == 'edit') {
            $select->where('schedule_id != ?', $id);

            if ($this->_params['field'] == 'start_time') {
                $select->where(new Zend_Db_Expr('(start_time BETWEEN \'' . $tmp['start_time'] . '\' AND \'' . $tmp['end_time'] . '\')'));
            } elseif ($this->_params['field'] == 'end_time') {
                $select->where(new Zend_Db_Expr('(end_time BETWEEN \'' . $tmp['start_time'] . '\' AND \'' . $tmp['end_time'] . '\')'));
            }
        } else {
            $select->where(new Zend_Db_Expr('(start_time BETWEEN \'' . $tmp['start_time'] . '\' AND \'' . $tmp['end_time'] . '\' OR end_time BETWEEN \'' . $tmp['start_time'] . '\' AND \'' . $tmp['end_time'] . '\')'));
        }

        $result = $this->_adapter->fetchAll($select, array(), Zend_Db::FETCH_ASSOC);

        $tmp['start_time'] = explode(':', $tmp['start_time']);
        $tmp['end_time'] = explode(':', $tmp['end_time']);
        $start_time = (int) $tmp['start_time'][0] * 60 + (int) $tmp['start_time'][1];
        $end_time = (int) $tmp['end_time'][0] * 60 + (int) $tmp['end_time'][1];

        foreach ($result as $event) {
            $event['start_time'] = explode(':', $event['start_time']);
            $event['end_time'] = explode(':', $event['end_time']);

            $event['start_time'] = (int) $event['start_time'][0] * 60 + (int) $event['start_time'][1];
            $event['end_time'] = (int) $event['end_time'][0] * 60 + (int) $event['end_time'][1];

            if ($this->_params['field'] == 'start_time') {
                //duplicate event
                if ($event['start_time'] == $start_time) {
                    $this->_error_name = self::DUPLICATE_TIME;
                    return false;
                }
                //creating event is in range
                if ($start_time > $event['start_time'] && $start_time < $event['end_time']) {
                    $this->_error_name = self::IS_IN_RANGE;
                    return false;
                }
            }
            if ($this->_params['field'] == 'end_time') {
                //duplicate event
                if ($event['end_time'] == $end_time) {
                    $this->_error_name = self::DUPLICATE_TIME;
                    return false;
                }
                //creating event is in range
                if ($end_time < $event['end_time'] && $end_time > $event['start_time']) {
                    $this->_error_name = self::IS_IN_RANGE;
                    return false;
                }
            }
        }



        return true;
    }

    public function isValid($value, $context = null) {
        $viewer = Engine_Api::_()->user()->getViewer();
        // Convert times
        $oldTz = date_default_timezone_get();
        date_default_timezone_set($viewer->timezone);
        $start_time = strtotime($context['start_time']['hour'] . ':' . $context['start_time']['minute']);
        $end_time = strtotime($context['end_time']['hour'] . ':' . $context['end_time']['minute']);
        date_default_timezone_set($oldTz);
        $tmp['start_time'] = date('H:i', $start_time);
        $tmp['end_time'] = date('H:i', $end_time);
        $tmp['user'] = $viewer->getIdentity();
        $tmp['date'] = $context['date'];

        $isValid = $this->_query($tmp);
        if ($isValid === false) {
            $this->_error($this->_error_name);
            return $isValid;
        }
        return $isValid;
    }

}