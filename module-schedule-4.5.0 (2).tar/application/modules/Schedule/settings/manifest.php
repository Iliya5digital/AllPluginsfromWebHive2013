<?php

return array(
    'package' =>
    array(
        'type' => 'module',
        'name' => 'schedule',
        'version' => '4.5.0',
        'path' => 'application/modules/Schedule',
        'title' => 'Schedule',
        'description' => 'Schedule',
        'author' => 'WebHive Team',
        'callback' => array(
            'path' => 'application/modules/Schedule/settings/install.php',
            'class' => 'Schedule_Installer',
        ),
        'actions' =>
        array(
            0 => 'install',
            1 => 'upgrade',
            2 => 'refresh',
            3 => 'enable',
            4 => 'disable',
        ),
        'directories' =>
        array(
            0 => 'application/modules/Schedule',
        ),
        'files' =>
        array(
            0 => 'application/languages/en/schedule.csv',
        ),
    ),
    // Items ---------------------------------------------------------------------
    'items' => array(
        'schedule',
        'setting',
        'reminder',
    ),
    //Hooks
    'hooks' => array(
        array(
            'event' => 'onUserDeleteBefore',
            'resource' => 'Schedule_Plugin_Core',
        ),
        array(
            'event' => 'onItemDeleteBefore',
            'resource' => 'Schedule_Plugin_Core',
        ),
    ),
    // Routes
    'routes' => array(
        'schedule_general' => array(
            'route' => 'schedule/:action/*',
            'defaults' => array(
                'module' => 'schedule',
                'controller' => 'index',
                'action' => 'index',
            ),
            'reqs' => array(
                'action' => '(index|create|settings)',
            ),
        ),
        'schedule_view' => array(
            'route' => 'schedule/:user_id/*/:date/*',
            'defaults' => array(
                'module' => 'schedule',
                'controller' => 'index',
                'action' => 'list',
            ),
            'reqs' => array(
                'user_id' => '\d+',
                'date' => '\d+',
            ),
        ),
        'schedule_specific' => array(
            'route' => 'schedule/:action/:schedule_id/*',
            'defaults' => array(
                'module' => 'schedule',
                'controller' => 'schedule',
                'action' => 'index',
            ),
            'reqs' => array(
                'action' => '(edit|delete|invite|accept|reject|users)',
                'schedule_id' => '\d+',
            )
        ),
        'schedule_reminder' => array(
            'route' => 'schedule/reminder/*',
            'defaults' => array(
                'module' => 'schedule',
                'controller' => 'schedule',
                'action' => 'reminder',
            ),
        ),
        'schedule_test' => array(
            'route' => 'schedule/test/*',
            'defaults' => array(
                'module' => 'schedule',
                'controller' => 'index',
                'action' => 'test',
            ),
        ),
    ),
);
?>