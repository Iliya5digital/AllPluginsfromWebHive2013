<?php

class Custommenu_Model_Item extends Core_Model_Item_Abstract {

}
