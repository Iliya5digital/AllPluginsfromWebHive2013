<?php return array (
  'package' => 
  array (
    'type' => 'module',
    'name' => 'custommenu',
    'version' => '4.3.0p3',
    'path' => 'application/modules/Custommenu',
    'title' => 'Custom Menu',
    'description' => 'Displays custom navigation menu with drop-down features.',
    'author' => 'WebHive Team',
    'callback' => 
    array (
      'class' => 'Engine_Package_Installer_Module',
    ),
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),    
    'callback' => array(
      'path' => 'application/modules/Custommenu/settings/install.php',
      'class' => 'Custommenu_Installer',
      'priority' => 5000,
    ),  
    'directories' => 
    array (
      0 => 'application/modules/Custommenu',
    ),
    'files' => 
    array (
      0 => 'application/languages/en/custommenu.csv',
    ),      
    'items' => array(
        'item'
    ),
  ),
); ?>