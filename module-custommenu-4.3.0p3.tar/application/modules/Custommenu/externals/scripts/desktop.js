window.addEvent('domready', function() {                           
    (function() {
        var index = 0;
        Element.implement({
            toggle: function() {
                var args = Array.slice(arguments, 0), count = args.length - 1;
                return this.addEvent('click', function(){
                    args[index].apply(this, arguments);
                    index = (count > index) ? index + 1 : 0;
                });
            }
        });
    })();

    var parents = $$('a.menu_open').getNext('ul');
    // hide all <ul>'s                
    Array.each(parents, function(el, index) {
        el.setStyle('display', 'none');        
    });

    $$('a.menu_open').toggle(
        function(e) {
            var parentList = $(this).getNext('ul');            
            var controls = parentList.getElements('span.submenu_open');            
            controls.dispose();                                  
                                    
            if (parentList.getElements('ul') != null) {                                
                parentList.setStyle('display', 'block');
                
                var children = parentList.getElements('ul'); 
                
                Array.each(children, function(child, index) {                    
                        new Element('span', {
                            'class' : 'submenu_open',
                            'html'  : '&nbsp;'                        
                        }).inject(child, 'before').addEvent('click', function(e) {
                            var childList = $(this).getNext('ul.custommenu-nav-subitem');                  
                        
                            if (childList.getStyle('display') == 'none') {
                                childList.setStyle('display', 'block');
                                $(this).set('html', '&nbsp;');
                                $(this).removeClass('up'); 
                                $(this).addClass('down'); 
                            } else {
                                childList.setStyle('display', 'none');
                                $(this).set('html', '&nbsp;');
                                $(this).removeClass('down'); 
                                $(this).addClass('up'); 
                            }                                               
                        });                     
                });
            }
        },
        function() {                                        
            var parentList = $(this).getNext('ul');  
            var childLists = parentList.getElements('ul.custommenu-nav-subitem');           
            var controls = parentList.getElements('span.submenu_open');           
            childLists.setStyle('display', 'none');
            controls.setStyle('display', 'none');
            parentList.setStyle('display', 'none');
            //controls.dispose();
        }
    );        
});

