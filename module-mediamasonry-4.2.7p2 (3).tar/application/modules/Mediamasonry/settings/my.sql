INSERT IGNORE INTO `engine4_core_menuitems`(`name`,`module`,`label`,`plugin`,`params`,`menu`,`submenu`,`enabled`,`custom`,`order`)
				    VALUES ('whmedia_admin_main_mediamasonry','mediamasonry','Masonry Add-on Settings','','{\"route\":\"admin_default\",\"module\":\"mediamasonry\",\"controller\":\"settings\",\"action\":\"mediamasonry\"}','whmedia_admin_main','',1,0,5);
