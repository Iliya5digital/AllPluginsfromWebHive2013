<?php

class Questiongeaddon_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}