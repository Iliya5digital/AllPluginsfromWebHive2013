INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, vars)
                                         VALUES ('notify_group_answer_new', 'question', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[unsubscribe_link],[resource_title],[resource_link]');
INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, vars)
                                         VALUES ('notify_group_choose_best', 'question', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[resource_title],[resource_link]');
INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, vars)
                                         VALUES ('notify_group_answer_new_subs', 'question', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[unsubscribe_link],[resource_title],[resource_link]');
INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, vars)
                                         VALUES ('notify_group_answer_new_comment', 'question', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[unsubscribe_link],[resource_title],[resource_link]');

INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, body, is_request, `handler`)
                                                 VALUES ('group_answer_new', 'question', '{item:$subject} has answered on your question {item:$object:$label} in the group {var:$resource}', 0, '');
INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, body, is_request, `handler`)
                                                 VALUES ('group_choose_best', 'question', '{item:$subject} has chosen the best answer to a question {item:$object:$label} in the group {var:$resource}', 0, '');
INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, body, is_request, `handler`)
                                                 VALUES ('group_answer_new_subs', 'question', '{item:$subject} has answered on question {item:$object:$label} in the group {var:$resource}', 0, '');
INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, body, is_request, `handler`)
                                                 VALUES ('group_answer_new_comment', 'question', '{item:$subject} has commented a question {item:$object:$label} in the group {var:$resource}', 0, '');

INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, vars)
                                         VALUES ('notify_event_answer_new', 'question', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[unsubscribe_link],[resource_title],[resource_link]');
INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, vars)
                                         VALUES ('notify_event_choose_best', 'question', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[resource_title],[resource_link]');
INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, vars)
                                         VALUES ('notify_event_answer_new_subs', 'question', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[unsubscribe_link],[resource_title],[resource_link]');
INSERT IGNORE INTO `engine4_core_mailtemplates` (`type`, `module`, vars)
                                         VALUES ('notify_event_answer_new_comment', 'question', '[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[unsubscribe_link],[resource_title],[resource_link]');

INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, body, is_request, `handler`)
                                                 VALUES ('event_answer_new', 'question', '{item:$subject} has answered on your question {item:$object:$label} in the event {var:$resource}', 0, '');
INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, body, is_request, `handler`)
                                                 VALUES ('event_choose_best', 'question', '{item:$subject} has chosen the best answer to a question {item:$object:$label} in the event {var:$resource}', 0, '');
INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, body, is_request, `handler`)
                                                 VALUES ('event_answer_new_subs', 'question', '{item:$subject} has answered on question {item:$object:$label} in the event {var:$resource}', 0, '');
INSERT IGNORE INTO `engine4_activity_notificationtypes` (`type`, `module`, body, is_request, `handler`)
                                                 VALUES ('event_answer_new_comment', 'question', '{item:$subject} has commented a question {item:$object:$label} in the event {var:$resource}', 0, '');

INSERT IGNORE INTO `engine4_activity_actiontypes`(`type`,`module`,`body`,`enabled`,`displayable`,`attachable`,`commentable`,`shareable`,`is_generated`)
                                          VALUES ('ge_choose_best','question','{item:$subject} has chosen the best answer to the question: ',1,3,1,0,0,1),
                                                 ('ge_answer_new','question','{item:$subject} answered to {item:$owner}\'s question: ',1,3,1,0,0,1),
                                                 ('ge_question_new','question','{item:$subject} has asked a new question: ',1,3,1,0,0,1);