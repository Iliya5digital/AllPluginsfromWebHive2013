<?php

return array(
    'package' =>
    array(
        'type' => 'module',
        'name' => 'questiongeaddon',
        'version' => '4.2.9p1',
        'path' => 'application/modules/Questiongeaddon',
        'title' => 'Q&A: Groups/Events Addon',
        'description' => 'This module adds Question&Answers tab to groups and events (standard SocialEngine 4 modules).',
        'author' => 'WebHive Team',
        'dependencies' => array(
            array(
                'type' => 'module',
                'name' => 'question',
                'minVersion' => '4.2.9',
            ),
        ),
        'callback' =>
        array(
            'path' => 'application/modules/Questiongeaddon/settings/install.php',
            'class' => 'Questiongeaddon_Installer'
        ),
        'actions' =>
        array(
            0 => 'install',
            1 => 'upgrade',
            2 => 'refresh',
            3 => 'enable',
            4 => 'disable',
        ),
        'directories' =>
        array(
            0 => 'application/modules/Questiongeaddon',
        ),
        'files' =>
        array(
            0 => 'application/languages/en/questiongeaddon.csv',
        ),
    ),
);
?>