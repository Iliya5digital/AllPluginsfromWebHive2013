<?php

return array(
    array(
        'type' => 'widget',
        'name' => 'questiongeaddon.question-ge-addon',
        'version' => '4.2.3',
        'title' => 'Q&A tab for Groups and Events',
        'description' => 'This module adds Question&Answers tab to groups and events (standard SocialEngine 4 modules).',
        'category' => 'Questions',
        'defaultParams' => array(
                            'title' => 'Q&A',
                            'titleCount' => true,
                        ),
    )
) ?>
