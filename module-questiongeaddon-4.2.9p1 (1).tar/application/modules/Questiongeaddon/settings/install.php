<?php

class Questiongeaddon_Installer extends Engine_Package_Installer_Module
{
    public function onInstall() {
        parent::onInstall();
        $pages = array('group', 'event');
        $db     = $this->getDb();
        foreach ($pages as $page) {
            $name = $page . '_profile_index';
            $select = new Zend_Db_Select($db);
            $select
              ->from('engine4_core_pages')
              ->where('name = ?', $name)
              ->limit(1);
              ;
            $info = $select->query()->fetch();
            if (empty($info))
                continue;
            $select = new Zend_Db_Select($db);
            $select
              ->from('engine4_core_content')
              ->where('page_id = ?', $info['page_id'])
              ->where('name = "core.container-tabs"')
              ->limit(1);
              ;
            $container_tabs_info = $select->query()->fetch();
            $select = new Zend_Db_Select($db);
            $select
              ->from('engine4_core_content')
              ->where('page_id = ?', $info['page_id'])
              ->where('name = "questiongeaddon.question-ge-addon"')
              ->where('parent_content_id = ?', $container_tabs_info['content_id'])
              ->limit(1);
              ;
            $info_widget = $select->query()->fetch();
            if (!empty($info_widget))
                continue;
            $db->insert('engine4_core_content', array(
                                                        'type' => 'widget',
                                                        'name' => 'questiongeaddon.question-ge-addon',
                                                        'page_id' => $info['page_id'],
                                                        'parent_content_id' => $container_tabs_info['content_id'],
                                                        'params' => '{"title":"Q&A","titleCount":true}',
                                                        'order' => 999
                                                      ));
        }
       
    }

}
?>