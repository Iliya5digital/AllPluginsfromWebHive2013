<?php

class Questiongeaddon_Widget_QuestionGeAddonController extends Engine_Content_Widget_Abstract
{
  protected $_childCount;

  public function  __construct() {
    $this->setRequest(Zend_Controller_Front::getInstance()->getRequest());
  }

  public function indexAction()
  {
    // Don't render this if not authorized
    $viewer = Engine_Api::_()->user()->getViewer();
    if( !Engine_Api::_()->core()->hasSubject() ) {
      return $this->setNoRender();
    }
    
    // Get subject and check auth
    $subject = Engine_Api::_()->core()->getSubject();
    $subjectType = $subject->getType();
    if ($subjectType != 'group' and $subjectType != 'event') {
        return $this->setNoRender();
    }
    if( !$subject->authorization()->isAllowed($viewer, 'view') ) {
      return $this->setNoRender();
    }
    if( !Engine_Api::_()->authorization()->isAllowed('question', $viewer, 'view') ) {
      return $this->setNoRender();
    }
    $this->view->paginator = $paginator = Engine_Api::_()->question()->getQuestionPaginator(array('resource' => array('resource_type' => $subject->getType(),
                                                                                                                      'resource_id' => $subject->getIdentity() )));
    $paginator->setItemCountPerPage(Engine_Api::_()->getApi('settings', 'core')->getSetting('question_page', 20));
    $paginator->setCurrentPageNumber((int)$this->_getParam('page', 1));
    $this->_childCount = $paginator->getTotalItemCount();
    $this->view->can_create = Engine_Api::_()->question()->can_create_question();
  }

  public function getChildCount() {
    return $this->_childCount;
  }

}