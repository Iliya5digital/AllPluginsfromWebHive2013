<?php

class Whfilters_FiltersController extends Core_Controller_Action_Standard {
  
  protected $_media;
  protected $_filtres = array('lomo', 'incwell', 'hippurple', 'hipblue', 'nashville', 'kelvin', 'toaster', 'gotham', 'tilt_shift', 'pencil_sketch', 'sigmoidal_contrast', 'texture_fabric', 'vintage', 'piglet');

  public function init() {
    $this->_isAjax = $isAjax = (bool)$this->_getParam('isajax', false);
    if (!$this->_helper->requireUser()->setNoForward()->isValid())
        return $this->_helper->Message('Please login.', false, false)->setError()->setAjax($isAjax);
    $media_id = (int)$this->_getParam('media_id', 0);
    if (empty ($media_id)) {
        return $this->_helper->Message('Incorrect media ID.', false, false)->setError()->setAjax($isAjax);
    }
    $media = Engine_Api::_()->getItem('whmedia_media', $media_id);
    if ($media !== null) {
        Engine_Api::_()->core()->setSubject($media);
        $this->_media = $media;
    }
    if (!$this->_helper->requireSubject('whmedia_media')->setNoForward()->isValid())
        return $this->_helper->Message('Incorrect media file.', false, false)->setError()->setAjax($isAjax);
    if (!$media->isOwner(Engine_Api::_()->user()->getViewer()))
        return $this->_helper->Message('Only owner can apply filters.', false, false)->setError()->setAjax($isAjax);
    if ($media->getMediaType() != 'image')
        return $this->_helper->Message('Media is not a image.', false, false)->setError()->setAjax($isAjax);
    if ($isAjax and !$this->getRequest()->isPost()) {
        return $this->_helper->Message("Invalid Data.", false, false)->setError()->setAjax(true);
    }
  }  
    
  public function indexAction() {

    $base_tmp_dir = APPLICATION_PATH . '/public/temporary/whfilters/';
    
    if( !is_dir($base_tmp_dir) ) {
        if( !mkdir($base_tmp_dir, 0777, true) ) {
            throw new Exception('Filters temporary directory did not exist and could not be created.');
        }
    }
    $media_tmp_dir = $base_tmp_dir . $this->_media->getIdentity() . '/';
    if( !is_dir($media_tmp_dir) ) {
        if( !mkdir($media_tmp_dir, 0777, true) ) {
            throw new Exception('Filters temporary directory did not exist and could not be created.');
        }
    }
    $file_tmp_new = $media_tmp_dir . 'image.jpg';
    if (!file_exists($file_tmp_new)) {
        $file_tmp = $this->_media->getFile()->temporary();
        $image = Engine_Image::factory(array('quality' => 100));
        $image->open($file_tmp)
            ->resize('640', '480')
            ->write($file_tmp_new)
            ->destroy();
    }
    $this->view->file_tmp = '/public/temporary/whfilters/' . $this->_media->getIdentity() . '/image.jpg';
   
    $this->view->navigation = Engine_Api::_()->whmedia()->getManageNavigation($this->_media->getParent());
  }
  
  public function getExampleFiltrAction() {
      $media_tmp_dir = APPLICATION_PATH . '/public/temporary/whfilters/' . $this->_media->getIdentity() . '/';
      $file_original = $media_tmp_dir . 'image.jpg';
      $filter = $this->_getParam('filter');
      if( !in_array($filter, $this->_filtres))
        return $this->_helper->Message("Invalid filter.", false, false)->setError()->setAjax(true);
      $file_filtr = $media_tmp_dir . $filter . '.jpg';
      if (!file_exists($file_filtr)) {
        try
            {
                copy($file_original, $file_filtr);
                $filtr_obj = new Whfilters_Library_ImageFilters($file_filtr);
                $filtr_obj->$filter();
            }
        catch (Exception $e) 
            {
                return $this->_helper->Message($e->getMessage(), false, false)->setError()->setAjax(true);
            }
      }
      return $this->_helper->json(array('status' => true));  
  }
  
  public function saveChoiceAction() {
      $filter = $this->_getParam('filter');
      if( !in_array($filter, $this->_filtres))
        return $this->_helper->Message("Invalid filter.", false, false)->setError();
      
      $media_tmp_dir = APPLICATION_PATH . '/public/temporary/whfilters/' . $this->_media->getIdentity();
      if (is_dir($media_tmp_dir)) {
        $objects = scandir($media_tmp_dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                unlink($media_tmp_dir."/".$object);
            }
        }
        reset($objects);
        rmdir($media_tmp_dir);
      }
      $files = Engine_Api::_()->getItemTable('storage_file')->fetchAll(array('parent_type = ?' => 'whmedia_media',
                                                                             'parent_id = ?' => $this->_media->getIdentity()));
      if (count($files)) {
          try {
            foreach ($files as $file) {
                $file_tmp = $file->temporary();
                $filtr_obj = new Whfilters_Library_ImageFilters($file_tmp);
                $filtr_obj->$filter();
                unset($filtr_obj);
                $file->store($file_tmp);
            }
          }
          catch (Exception $e) {
                return $this->_helper->Message($e->getMessage(), false, false)->setError();
          }
      }
      return $this->_helper->redirector->gotoRouteAndExit(array('project_id' => $this->_media->getParent()->getIdentity()), 'whmedia_project');
  }
}
