<?php

class Whfilters_Library_ImageFilters
{
    
    public $_image = NULL;
    private $_width = NULL;
    private $_height = NULL;
    private $_tmp = NULL;
         
    # class constructor
    
    public function __construct($image)
    {
        if(file_exists($image))
        {
            $this->_image = $image;
            list($this->_width, $this->_height) = getimagesize($image);
        }
        else
        {
            throw new Exception('File not found. Aborting.');
        }
    }

    public function tempfile()
    {
        # copy original file and assign temporary name
        $this->_tmp = $this->_image;
    }

    public function execute($command)
    {
        # remove newlines and convert single quotes to double to prevent errors
        $command = str_replace(array("\n", "'"), array('', '"'), $command);
        # replace multiple spaces with one
        $command = preg_replace('#(\s){2,}#is', ' ', $command);
        # escape shell metacharacters
        $command = escapeshellcmd($command);
        # execute convert program
        exec($command);
    }
    
    /** ACTIONS */
    
    public function colortone($input, $color, $level, $type = 0)
    {
        $args[0] = $level;
        $args[1] = 100 - $level;
        $negate = $type == 0? '-negate': '';

        $this->execute("convert 
        {$input} 
        ( -clone 0 -fill $color -colorize 100% ) 
        ( -clone 0 -colorspace gray $negate ) 
        -compose blend -define compose:args=$args[0],$args[1] -composite 
        {$input}");
    }

    public function border($input, $color = 'black', $width = 20)
    {
        $this->execute("convert $input -bordercolor $color -border {$width}x{$width} $input");
    }

    public function frame($input, $frame)
    {
        $prefix = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'application' . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'Whfilters' . DIRECTORY_SEPARATOR . 'Library' . DIRECTORY_SEPARATOR . 'filters_covers' . DIRECTORY_SEPARATOR;
        $this->execute("convert $input ( {$prefix}{$frame} -resize {$this->_width}x{$this->_height}! -unsharp 1.5×1.0+1.5+0.02 ) -flatten $input");
    }
    
    public function vignette($input, $color_1 = 'none', $color_2 = 'black', $crop_factor = 2.0)
    {
        $crop_x = floor($this->_width * $crop_factor);
        $crop_y = floor($this->_height * $crop_factor);
        
        $this->execute("convert 
        ( {$input} ) 
        ( -size {$crop_x}x{$crop_y} 
        radial-gradient:$color_1-$color_2 
        -gravity center -crop {$this->_width}x{$this->_height}+0+0 +repage )
        -compose multiply -flatten 
        {$input}");   
    }
	
    /** FILTER METHODS */
    
    # GOTHAM
    public function gotham()
    {
        $this->tempfile();
        //$this->execute("convert $this->_tmp -modulate 120,10,100 -fill #222b6d -colorize 20 -gamma 0.5 -contrast -contrast $this->_tmp");
		$this->execute("convert $this->_tmp -modulate 120,10,100 -fill #222b6d -colorize 20 -gamma 1 -contrast -contrast $this->_tmp");
        $this->border($this->_tmp);
    }

    # TOASTER
    public function toaster()
    {
        $this->tempfile();
        $this->colortone($this->_tmp, '#330000', 100, 0);        
        $this->execute("convert $this->_tmp -modulate 150,80,100 -gamma 1.5 -contrast -contrast $this->_tmp");        
        $this->vignette($this->_tmp, 'none', 'LavenderBlush3');
        $this->vignette($this->_tmp, 'none', '#ff9966');

      
    }
    
    # NASHVILLE
    public function nashville()
    {
        $this->tempfile();
        
        $this->colortone($this->_tmp, '#222b6d', 100, 0);
        $this->colortone($this->_tmp, '#f7daae', 100, 1);
        
        $this->execute("convert $this->_tmp -contrast -modulate 100,150,100 -auto-gamma $this->_tmp");
        $this->frame($this->_tmp, __FUNCTION__);

    }
        
    # LOMO-FI
    public function lomo()
    {
        $this->tempfile();
        
        $command = "convert $this->_tmp -channel R -level 0% -channel G -level 10% $this->_tmp";
        
        $this->execute($command);
        $this->vignette($this->_tmp);

    }
	
    # KELVIN
    public function kelvin()
    {
        $this->tempfile();
        //( -size {$this->_width}x{$this->_height} -fill rgba(255,153,0,0.5) -draw 'rectangle 0,0 {$this->_width},{$this->_height}' )
        $this->execute("convert 
        ( $this->_tmp -auto-gamma -modulate 120,50,100 )        
		( -size {$this->_width}x{$this->_height} -fill rgba(172,122,51,0.4) -draw 'rectangle 0,0 {$this->_width},{$this->_height}' )  
        -compose multiply 
        $this->_tmp");
        $this->frame($this->_tmp, __FUNCTION__);

    }

    # TILT SHIFT
    public function tilt_shift()
    {
        $this->tempfile();

        $this->execute("convert 
        ( $this->_tmp -gamma 0.75 -modulate 100,130 -contrast ) 
        ( +clone -sparse-color Barycentric '0,0 black 0,%h white' -function polynomial 4,-4,1 -level 0,50% ) 
        -compose blur -set option:compose:args 5 -composite 
        $this->_tmp");

    }
    # Pencil Sketch
    public function pencil_sketch()
    {
        $this->tempfile();

        $this->execute("convert $this->_tmp -colorspace gray -sketch 0x10+120 $this->_tmp");

    }
    
    # Sigmoidal Contrast
    public function sigmoidal_contrast()
    {
        $this->tempfile();

        $this->execute("convert $this->_tmp -sigmoidal-contrast 5,50% $this->_tmp");

    }
    # Texture Fabric
    public function texture_fabric()
    {
        $this->tempfile();
        $prefix = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'application' . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'Whfilters' . DIRECTORY_SEPARATOR . 'Library' . DIRECTORY_SEPARATOR . 'filters_covers' . DIRECTORY_SEPARATOR;
        $this->execute("composite {$prefix}texture_fabric.gif $this->_tmp -tile   -compose Hardlight  $this->_tmp");

    }
    
	# Incwell
    public function incwell()
    {
        $this->tempfile();
        $prefix = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'application' . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'Whfilters' . DIRECTORY_SEPARATOR . 'Library' . DIRECTORY_SEPARATOR . 'filters_covers' . DIRECTORY_SEPARATOR;
		//$this->execute("convert $this->_tmp -background black -vignette 0x50-50-125% {$prefix}incwell_colors.png -hald-clut $this->_tmp");
		$this->execute("convert $this->_tmp -background black -vignette 0x100-100-100% {$prefix}incwell_colors.png -hald-clut $this->_tmp");
		$this->execute("convert $this->_tmp -modulate 120,10,100 -fill #222b6d -colorize 0 -gamma 1 -contrast $this->_tmp");
    }
	    
    # Vintage
    public function vintage()
    {
        $this->tempfile();
        $prefix = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'application' . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'Whfilters' . DIRECTORY_SEPARATOR . 'Library' . DIRECTORY_SEPARATOR . 'filters_covers' . DIRECTORY_SEPARATOR;		
        $this->execute("convert $this->_tmp -background black -vignette 0x100-100-100% {$prefix}retro_colors.png -hald-clut $this->_tmp");
    }
	
    # Hip-Purple
    public function hippurple()
    {
        $this->tempfile();
        $prefix = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'application' . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'Whfilters' . DIRECTORY_SEPARATOR . 'Library' . DIRECTORY_SEPARATOR . 'filters_covers' . DIRECTORY_SEPARATOR;		
        $this->execute("convert $this->_tmp -background black -vignette 0x100-100-100% {$prefix}hippurple.png -hald-clut $this->_tmp");
    }

    # Hip-Blue
    public function hipblue()
    {
        $this->tempfile();
        $prefix = APPLICATION_PATH . DIRECTORY_SEPARATOR . 'application' . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'Whfilters' . DIRECTORY_SEPARATOR . 'Library' . DIRECTORY_SEPARATOR . 'filters_covers' . DIRECTORY_SEPARATOR;		
        $this->execute("convert $this->_tmp -background black -vignette 0x100-100-100% {$prefix}hipblue.png -hald-clut $this->_tmp");
    }		
    
    # Piglet
    public function piglet()
    {
        $this->tempfile();

        $this->execute("convert $this->_tmp -colorspace Gray -edge 1 -negate $this->_tmp");

    }
}