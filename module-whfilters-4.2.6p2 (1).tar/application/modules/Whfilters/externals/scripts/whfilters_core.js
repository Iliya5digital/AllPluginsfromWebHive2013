var whfilters = new Class({
    Implements:[Options],
    options:{
        lang:null,
        module: 'whfilters',
        controller: 'filters',
        url_prefix: null,
        media_id: null
    },
    current_filtr: null,
    loading_image: null,
    loaded_ex:['image'],
    initialize:function(a){
        this.setOptions(a);
        this.loading_image = new Asset.image('application/modules/Core/externals/images/loading.gif',{id : 'wh_loader'});
        },
    run_JSON: function(action, data, SuccessFunction) {
        new Request.JSON({
                 'url' : this.getURL(action),
                 'data': $extend(data, {'isajax' : true, 'format':'json'}),
                 'onSuccess' : function(responseObject) {
                    if( $type(responseObject)!="object" ) {
                        alert('ERROR occurred. Please try againe.');
                        return false;
                    }
                    if( !responseObject.status || responseObject.status !=true ) {
                        if (responseObject.reload == true)
                            window.location.reload(true);
                        if( responseObject.error && $type(responseObject.error) == 'string' ) {
                            alert(responseObject.error);
                        }
                        return false;
                    }
                    if (responseObject.status == true) {
                      delete responseObject.status;
                      SuccessFunction(responseObject);
                      return false;
                    }
                }.bind(this)
              }).send();
    },
    getURL : function(action) {
        return en4.core.baseUrl + this.options.url_prefix + '/' + this.options.controller + '/' + this.options.media_id + '/' + action;
    },
    getExampleFiltr: function(filtr) {
        if (this.current_filtr == filtr) return;
        if (!this.loaded_ex.contains(filtr)) {
            this.loading_image.inject($('example_img_div').empty());
            this.run_JSON('get-example-filtr', 
                        {'filter' : filtr, 
                        'media_id' : this.options.media_id}, 
                        function() {
                                        this.loaded_ex.push(filtr);
                                        this.setImage(filtr);
                                        
                                    }.bind(this));
        }
        else {
            this.setImage(filtr);
        }
        this.current_filtr = filtr;
        if (filtr != 'image') {
            $('save_button').setStyle('display', '');
        }
        else {
            $('save_button').setStyle('display', 'none');
        }
    },
    setImage: function(img) {
        Asset.image(en4.core.baseUrl + 'public/temporary/whfilters/' + this.options.media_id + '/' + img + '.jpg', {
                                                                                                                alt: en4.core.language.translate('Example image'),
                                                                                                                onLoad: function(img){
                                                                                                                    img.inject($('example_img_div').empty());
                                                                                                                }
        });
    },
    saveChoice: function() {
        var form = new Element('form', {
                                        action: this.getURL('save-choice'),
                                        method: 'post',
                                        target: '_parent'
                                    });
        new Element('input', {type: 'hidden',
                              value: this.current_filtr,
                              name: 'filter'}).inject(form);
        document.body.appendChild(form);
        form.submit();                          
    }
});