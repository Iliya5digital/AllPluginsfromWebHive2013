<?php

class Whfilters_Bootstrap extends Engine_Application_Bootstrap_Abstract
{
    protected function _initRouter() {
        defined('WHMEDIA_URL_WORLD') || define('WHMEDIA_URL_WORLD', Engine_Api::_()->getApi('settings', 'core')->getSetting('url_main_world', 'whmedia'));
        $router = Zend_Controller_Front::getInstance()->getRouter();
        $userConfig = array('whfilters_image_filters' => array('route' => WHMEDIA_URL_WORLD . '/filters/:media_id/:action/*',
                                                             'defaults' => array(
                                                                'module' => 'whfilters',
                                                                'controller' => 'filters',
                                                                'action' => 'index'
                                                             ),
                                                            'reqs' => array(
                                                                    'action' => '(index|get-example-filtr|save-choice)',
                                                                    'media_id' => '\d+'
                                                            )
                                 )
            );
        $router->addConfig(new Zend_Config($userConfig));
        return $router;
    }
}