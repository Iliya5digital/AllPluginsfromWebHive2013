<?php

class Whfilters_Installer extends Engine_Package_Installer_Module {
    
  public function onPreInstall() {
      parent::onPreInstall();
      exec('convert -version', $output, $return);
      if( $return > 0 ) {
        return $this->_error("Image Filters addon requires ImageMagick to be installed on the server. Contact your hosting support to make sure it's available.");
      }      
  }  
}
?>