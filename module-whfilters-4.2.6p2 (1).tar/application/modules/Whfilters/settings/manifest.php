<?php return array (
  'package' => 
  array (
    'type' => 'module',
    'name' => 'whfilters',
    'version' => '4.2.6p2',
    'path' => 'application/modules/Whfilters',
    'title' => 'Media Addon: Filters',
    'description' => 'This extension for Media adds functionality to apply photo filters for images in projects.',
    'author' => 'WebHive Team',
    'dependencies' => array(
                            array(
                                'type' => 'module',
                                'name' => 'whmedia',
                                'minVersion' => '4.2.4p3',
                            )
    ),
    'callback' => 
    array (
      'path' => 'application/modules/Whfilters/settings/install.php',
      'class' => 'Whfilters_Installer'
    ),
    'actions' => 
    array (
      0 => 'install',
      1 => 'upgrade',
      2 => 'refresh',
      3 => 'enable',
      4 => 'disable',
    ),
    'directories' => 
    array (
      0 => 'application/modules/Whfilters',
    ),
    'files' => 
    array (
      0 => 'application/languages/en/whfilters.csv',
    ),
  ),
); ?>