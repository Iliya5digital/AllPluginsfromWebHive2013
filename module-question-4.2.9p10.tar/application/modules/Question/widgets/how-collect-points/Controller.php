<?php

class Question_Widget_HowCollectPointsController extends Engine_Content_Widget_Abstract
{
  public function indexAction() {}

}

