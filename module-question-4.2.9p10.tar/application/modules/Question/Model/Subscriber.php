<?php

class Question_Model_Subscriber extends Core_Model_Item_Abstract {
    protected $_searchColumns = array();
}