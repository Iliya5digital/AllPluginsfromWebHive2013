<?php     

class Question_Model_Qvote extends Question_Model_Vote {
   protected $_type = 'qvote';
}