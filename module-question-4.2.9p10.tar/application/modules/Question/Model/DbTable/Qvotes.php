<?php

class Question_Model_DbTable_Qvotes extends Question_Model_DbTable_Votes {

  protected $_rowClass = 'Question_Model_Qvote';

}