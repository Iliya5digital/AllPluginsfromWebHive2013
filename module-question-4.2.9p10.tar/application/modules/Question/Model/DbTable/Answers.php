<?php

class Question_Model_DbTable_Answers extends Engine_Db_Table
{

  protected $_rowClass = 'Question_Model_Answer';
}