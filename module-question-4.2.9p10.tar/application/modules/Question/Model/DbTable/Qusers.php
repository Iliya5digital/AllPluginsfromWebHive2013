<?php

class Question_Model_DbTable_Qusers extends User_Model_DbTable_Users
{
    protected $_rowClass = 'Question_Model_Quser';

}