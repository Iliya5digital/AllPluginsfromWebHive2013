<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    HelloWorld
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.net/license/
 * @version    $Id: Bootstrap.php 2012 2009-12-20 07:07:23Z john $
 * @author     John Boehr <j@webligo.com>
 */

/**
 * @category   Application_Extensions
 * @package    HelloWorld
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.net/license/
 */
class Question_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}