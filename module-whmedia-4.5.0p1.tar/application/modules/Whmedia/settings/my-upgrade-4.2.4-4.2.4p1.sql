ALTER TABLE `engine4_whmedia_projects` ADD COLUMN `anonymous` INT(1)  NOT NULL DEFAULT '0' AFTER `comment_count`;
