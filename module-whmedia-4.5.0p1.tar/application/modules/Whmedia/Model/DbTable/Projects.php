<?php

class Whmedia_Model_DbTable_Projects extends Engine_Db_Table
{
  protected $_rowClass = 'Whmedia_Model_Project';
}