<?php

class Whmedia_Model_DbTable_Medias extends Engine_Db_Table
{
  protected $_rowClass = 'Whmedia_Model_Media';
}