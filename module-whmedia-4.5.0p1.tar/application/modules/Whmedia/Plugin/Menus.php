<?php

class Whmedia_Plugin_Menus
{
  public function canCreateProjects()
  {
    // Must be logged in
    $viewer = Engine_Api::_()->user()->getViewer();
    if( !$viewer || !$viewer->getIdentity() ) {
      return false;
    }

    // Must be able to create media projects
    if( !Engine_Api::_()->authorization()->isAllowed('whmedia_project', $viewer, 'create') ) {
      return false;
    }
    if (Engine_Api::_()->whcore()->isApple()) {
        return false;
    }
    return true;
  }

  public function canViewProjects()
  {
    $viewer = Engine_Api::_()->user()->getViewer();
    
    // Must be able to view media projects
    if( !Engine_Api::_()->authorization()->isAllowed('whmedia_project', $viewer, 'view') ) {
      return false;
    }

    return true;
  }

  public function onMenuInitialize_WhmediaMainProject($row)
  {
    if( !Engine_Api::_()->core()->hasSubject('whmedia_project') ) {
      return false;
    }

    $viewer = Engine_Api::_()->user()->getViewer();
    $project = Engine_Api::_()->core()->getSubject('whmedia_project');

    if( !$project->isOwner($viewer)) {
      return false;
    }
    if (Engine_Api::_()->whcore()->isApple()) {
        return false;
    }
    // Modify params
    $params = $row->params;
    $params['params']['project_id'] = $project->getIdentity();
    return $params;
  }

}