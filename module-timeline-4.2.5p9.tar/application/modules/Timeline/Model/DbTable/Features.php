<?php
class Timeline_Model_DbTable_Features extends Engine_Db_Table {
    protected $_rowClass = 'Timeline_Model_Feature';
}