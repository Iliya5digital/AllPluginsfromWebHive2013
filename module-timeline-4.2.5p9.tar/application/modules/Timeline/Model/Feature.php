<?php

class Timeline_Model_Feature extends Core_Model_Item_Abstract
{
    protected $_searchTriggers = false;
}