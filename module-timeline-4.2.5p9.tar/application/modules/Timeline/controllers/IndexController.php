<?php

Engine_Loader::autoload('application_modules_Activity_controllers_IndexController');

class Timeline_IndexController extends Activity_IndexController {

}
