<?php
Engine_Loader::autoload('application_modules_User_controllers_ProfileController');
class Timeline_ProfileController extends User_ProfileController
{
  
}