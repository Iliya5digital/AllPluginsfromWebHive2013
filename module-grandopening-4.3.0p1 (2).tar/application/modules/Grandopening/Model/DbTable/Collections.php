<?php
class Grandopening_Model_DbTable_Collections extends Engine_Db_Table {
    protected $_rowClass = 'Grandopening_Model_Collection';
}